import React from "react";
import { Text } from "react-native";

const Message=()=>{
    return <Text>Message</Text>
}

export default Message;