import React from "react";
import { Text } from "react-native";


const Match=()=>{


    return <Text>Match</Text>

}

export default Match;