import React from "react";
import { Text } from "react-native";

const Activity=()=>{
    return <Text>Activity</Text>
    

}

export default Activity;