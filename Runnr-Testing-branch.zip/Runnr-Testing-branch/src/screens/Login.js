import React from "react";
import { Text,View } from "react-native";
const Login=()=>{
    
    
    return(<View>
        <Text>This is the login screen</Text>

    </View>
    )
};

export default Login;