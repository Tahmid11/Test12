import React from "react";
import { Text } from "react-native";

const EditProfile=()=>{
    return <Text>Edit Profile</Text>

}

export default EditProfile;